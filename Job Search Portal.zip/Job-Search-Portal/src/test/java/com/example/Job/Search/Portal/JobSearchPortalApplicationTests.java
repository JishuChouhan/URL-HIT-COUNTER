package com.example.Job.Search.Portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobSearchPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
