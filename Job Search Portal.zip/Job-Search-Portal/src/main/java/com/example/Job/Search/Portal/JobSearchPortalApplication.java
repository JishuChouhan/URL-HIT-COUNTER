package com.example.Job.Search.Portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobSearchPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobSearchPortalApplication.class, args);
	}

}
